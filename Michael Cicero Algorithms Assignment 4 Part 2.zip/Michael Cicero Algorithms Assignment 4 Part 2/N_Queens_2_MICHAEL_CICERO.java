
public class N_Queens_2_MICHAEL_CICERO {   // Number of Solutions

   public static String yourName = "MICHAEL_CICERO";
   

//////////////////////////////////////////////////////////////////////
// Problem 2

   public static int nQueens_numSolns(int n)  {
      int [] col = new int[n+1];
      nQueens_numSolns_Rec(0, col, n);

      return col[0];
   }
   
   
   public static void nQueens_numSolns_Rec(int i, int [] col, int n)  {
      if (nQueensPromising(i, col))  {

         if (i == n)
            col[0]= col[0] + 1;
         else
         {
            for (int g = 1; g <= n; g++)
            {
               col[i+1] = g;
               nQueens_numSolns_Rec(i+1, col, n);
            }
         }
      }






   } 
   
   
   public static boolean nQueensPromising(int i, int [] col)  {

      for (int j = 1; j < i; j++)
      {
         if (col[i] == col[j])
            return false;
         else if (i - col[i] == j - col[j])
            return false;
         else if (i + col[i] == j + col[j])
            return false;
      }

      return true;

   }
       


//////////////////////////////////////////////////////////////////////
// Problem 7  (+5 pts extra credit)

   public static int nQueens_numSolns_extra(int n)  {
   


      return -999;
   }
   
   
   public static int nQueens_numSolns_Rec_extra(int i, int [] col, int n)  {
   
   
      return -999;
   }
   




// ===== main and printArray =============================================

   public static void main(String [] args)  {
   
      System.out.println("\n" + yourName);
      System.out.println("N_Queens_2:  number of solutions");
      int numSolutions = 0;
      

      for (int i = 4; i <= 10; i++)
      {
         System.out.print("\nCall to nQueens_numSolns(" + i + "):  ");
         numSolutions = nQueens_numSolns(i);
         System.out.println(numSolutions + " solutions found.");
         
         
         // UNCOMMENT next three lines if you are doing the extra credit (Problem 7)
         
//         System.out.print("Call to nQueens_numSolns_extra(" + i + "):  ");
//         numSolutions = nQueens_numSolns_extra(i);
//         System.out.println(numSolutions + " solutions found.");
       
      }

   }

   public static void printArray(int n, int [] A) {
      for (int i = 1; i <= n; i++)
         System.out.print(A[i] + " ");
      System.out.println();
   }

      
}
