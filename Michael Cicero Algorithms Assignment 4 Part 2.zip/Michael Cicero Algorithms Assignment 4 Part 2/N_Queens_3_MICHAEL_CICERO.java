
public class N_Queens_3_MICHAEL_CICERO { // print k solutions

   public static String yourName = "MICHAEL CICERO";


   public static void nQueens_Print_k_solns(int n, int k)  {
      int [] col = new int[n+1];
      nQueens_Print_k_solns_Rec(0, col, n, k);



   }
   
   
   public static void nQueens_Print_k_solns_Rec(int i, int [] col, int n, int k)  {
      int count = 0;
      if (nQueensPromising(i, col))  {

         if (i == n) {
            printArray(n, col);
            col[0] = col[0] + 1;
         }

         else
         {
            for (int g = 1; g <= n && col[0] < k; g++)
            {
               col[i+1] = g;

               nQueens_Print_k_solns_Rec(i+1, col, n, k);
            }
         }
      }






   }
   
   
   public static boolean nQueensPromising(int i, int [] col)  {
      for (int j = 1; j < i; j++)
      {
         if (col[i] == col[j])
            return false;
         else if (i - col[i] == j - col[j])
            return false;
         else if (i + col[i] == j + col[j])
            return false;
      }

      return true;

   }
       


// ===== main and printArray =============================================

   public static void main(String [] args)  {
   
      System.out.println("\n" + yourName);
      System.out.println("N_Queens_3:  print k solutions");


      for (int i = 4; i <= 10; i++)
      {      
         for (int k = 1; k <= 5; k += 2)
         {
            System.out.println("\nCall to nQueens_Print_k_solns(" + i + ", " + k + "):  ");
            nQueens_Print_k_solns(i, k);
         }
         System.out.println();
      }
      
      System.out.println();
      
   }

      
   public static void printArray(int n, int [] A) {
      for (int i = 1; i <= n; i++)
         System.out.print(A[i] + " ");
      System.out.println();
   }
   
}
