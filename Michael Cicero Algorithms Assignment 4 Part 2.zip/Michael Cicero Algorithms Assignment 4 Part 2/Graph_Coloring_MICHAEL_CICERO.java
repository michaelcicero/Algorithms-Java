
import java.util.Scanner;
import java.io.*;

public class Graph_Coloring_MICHAEL_CICERO{

   public static String yourName = "MICHAEL CICERO";

//////////////////////////////////////////////////////////////////////
// Problem 4

   public static boolean mColorable(int n, int [][] W, int m, int [] vcolor)  {

      return mColorableRec(0, n, W, m, vcolor);

   }  // end "mColorable"


   public static boolean mColorableRec(int i, int n, int [][] W, int m, int [] vcolor)  {
      int count = 0;
      int j = 0;
      if(promising(i, W, vcolor))
         if(i == n){
            return true;
         }
         else{
            for(j = 1; j <= m; j++){
               vcolor[i + 1] = j;
               if(mColorableRec(i + 1, n, W, m, vcolor))
                  return true;
            }


         }

      return false;
   } // end "mColorRec"


   public static boolean promising(int i, int [][] W, int [] vcolor)  {

      for (int j = 1; j < i; j++) {
         if(vcolor[i] == vcolor[j] && W[i][j] == 1)
            return false;


      }



      return true;

   }  // end "promising"



//////////////////////////////////////////////////////////////////////
// Problem 5

   public static boolean fastTwoColor(int n, int [][] W, int [] vcolor)  {

      IntQueue q = new IntQueue();
      vcolor[1] = 1;
      q.enqueue(1);

      while(!q.isEmpty()){
         int t = q.dequeue();
         for (int i = 1; i <= n ; i++) {
            if(W[i][t] == 1){
               if(vcolor[i] == vcolor[t])
                  return false;
               if(vcolor[i] == 0){
                  vcolor[i] = vcolor[t] % 2 + 1;
                  q.enqueue(i);
               }
            }

         }
      }




      return true;
   } // end "twoColor"



//////////////////////////////////////////////////////////////////////
// Problem 6

   public static int greedyColoring(int n, int [][] W, int [] vcolor)  {
      int count = 0;
      int curr = 0;

      while(count < n) {
         curr++;
         for (int i = 1; i <= n ; i++) {
            if(vcolor[i] == 0) {
               vcolor[i] = curr;
               if (!promising(i, W, vcolor))
                  vcolor[i] = 0;
               else {
                  count++;
               }
            }
         }
      }

      return curr;
   }




//////////////////////////////////////////////////////////////////////
// Main Method--you may comment out calls to test your
// methods one a time. When you turn it in, leave all
// methods uncommented.

   public static void main(String [] args)  throws IOException   {

      System.out.println("\n" + yourName);
      System.out.println("Graph Coloring Methods");

      Scanner kbd = new Scanner(System.in);
      int i, j, n, m, graphNum = 0;
      int [] vcolor;
      int [][] W;
      boolean found;
      long start, end;

      FileReader f = new FileReader("graphs.txt");
      Scanner input = new Scanner(f);

      n = input.nextInt();

      while (n > 0)  {

         graphNum++;

         W = new int[n+1][n+1];
         for (i = 1; i <= n; i++)
            for (j = 1; j <= n; j++)
               W[i][j] = input.nextInt();

         System.out.println("=============================================================");
         System.out.println("\nGraph " + graphNum + ", size = " + n + "\n");

         // Greedy Coloring:
         vcolor = new int[n+1];
         start =  System.currentTimeMillis();
         m = greedyColoring(n, W, vcolor);
         end =  System.currentTimeMillis();
         System.out.println(m + " colors are used by the Greedy Algorithm for Graph " + graphNum + ":");
         printArray(n, vcolor);
         System.out.println("This took " + (end - start) + " milliseconds to run.");

         // Backtracking--min colors needed:

         vcolor = new int[n+1];
         System.out.println();
         start =  System.currentTimeMillis();
         m = 1;
         while (!(mColorable(n, W, m, vcolor)))  {
            System.out.println("This graph is NOT " + m + "-colorable.");
            m++;
         }
         end =  System.currentTimeMillis();
         System.out.println(m + " colors are necessary for Graph " + graphNum + ":");
         printArray(n, vcolor);
         System.out.println("It took " + (end - start) + " milliseconds to determine this.");



         // Fast two-coloring algorithm:

         vcolor = new int[n+1];
         System.out.println("\nRunning fast two-coloring algorithm...");
         start =  System.currentTimeMillis();
         found = fastTwoColor(n, W, vcolor);
         end =  System.currentTimeMillis();

         if (found)  {
            System.out.println("2-coloring FOUND:");
            printArray(n, vcolor);
         }
         else
            System.out.println("No 2-coloring found!");

         System.out.println("This took " + (end - start) + " milliseconds to run.\n");

         // check for another graph:

         n = input.nextInt();

      } // end while (n > 0)
   } // end main

   public static void printArray(int n, int [] A) {
      for (int i = 1; i <= n; i++)
         System.out.print(A[i] + " ");
      System.out.println();
   }




} // end class
